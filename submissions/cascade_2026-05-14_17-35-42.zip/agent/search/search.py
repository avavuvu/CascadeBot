from typing import Optional

import numpy as np

from ..actions.generator import generate_legal_actions
from ..board import Board
from ..player_color import PlayerColor
from ..search.order_moves import _order_place_actions, order_moves
from ..transposition.table import FLAG_EXACT, FLAG_LOWER, FLAG_UPPER, TranspositionTable
from .evaluate import evaluate

_table = TranspositionTable()

# practically infinity.
INF = 1000


def get_best_move(
    board: Board,
    color: PlayerColor,
    depth: int = 6,
) -> Optional[np.void]:
    actions = generate_legal_actions(board, color)
    if len(actions) == 0:
        return None

    if board.is_place_book:
        place_actions = _order_place_actions(actions, board, color)
        return place_actions[0]

    _table.clear()

    best_action = actions[0]
    best_score = -INF

    for action in actions:
        board.make_move(action, color)

        if board.is_repeated:
            board.unmake_move()
            continue

        score = -_search(board, -INF, -best_score, color.opponent(), depth - 1)
        board.unmake_move()

        if score > best_score:
            best_score = score
            best_action = action

    return best_action


def _search(
    board: Board,
    alpha: int,
    beta: int,
    color: PlayerColor = PlayerColor.RED,
    depth: int = 6,
) -> int:
    if not np.any(board.board & np.uint8(color.value)):
        return -(INF + depth)

    key = board.zobrist_key
    cached = _table.probe(key, depth, alpha, beta)
    if cached is not None:
        return cached

    if depth == 0:
        score = evaluate(board, color)
        _table.store(key, depth, score, FLAG_EXACT)
        return score

    actions = generate_legal_actions(board, color)
    sorted_actions = order_moves(actions, board, color)

    original_alpha = alpha
    has_legal_move = False

    for action in sorted_actions:
        board.make_move(action, color)

        # Skip any move that revisits a position already on this path.
        if board.is_repeated:
            board.unmake_move()
            continue

        has_legal_move = True
        eval: int = -_search(board, -beta, -alpha, color.opponent(), depth - 1)
        board.unmake_move()

        if eval >= beta:
            _table.store(key, depth, beta, FLAG_LOWER)
            return beta

        if eval > alpha:
            alpha = eval

    if not has_legal_move:
        score = -(INF + depth)
        _table.store(key, depth, score, FLAG_EXACT)
        return score

    flag = FLAG_EXACT if alpha > original_alpha else FLAG_UPPER
    _table.store(key, depth, alpha, flag)
    return alpha
