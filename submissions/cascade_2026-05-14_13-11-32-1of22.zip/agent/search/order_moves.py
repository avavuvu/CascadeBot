import numpy as np

from ..actions.types import CASCADE_ACTION, EAT_ACTION
from ..board import Board
from ..direction import NEIGHBOR_TABLE
from ..player_color import PlayerColor

_sq = np.arange(64)
_CENTRE_DIST = np.abs(_sq // 8 * 2 - 7) + np.abs(_sq % 8 * 2 - 7)


def _has_stronger_enemy_neighbour(
    dest: int, our_height: int, board: np.ndarray, opp_mask: np.uint8
) -> bool:
    for nb in NEIGHBOR_TABLE[dest]:
        if nb >= 0:
            piece = int(board[nb])
            if piece & opp_mask and (piece & 0x0F) > our_height:
                return True
    return False


def _order_place_actions(actions: np.ndarray) -> np.ndarray:
    coords = actions["coord"].astype(np.intp)
    dist = _CENTRE_DIST[coords]
    return actions[np.argsort(dist, kind="stable")]


def order_moves(actions: np.ndarray, board: Board, color: PlayerColor):
    """

    Move phase priority:
    0  destination holds an enemy piece with height <= our height
    1  EAT_ACTION
    2  CASCADE whose path passes through at least one enemy piece
    3  neutral
    4  a neighbour of the destination is an enemy with height > our height
       (moving into attack range — deprioritised)
    """

    opp_mask = np.uint8(color.opponent().value)

    n = len(actions)
    keys = np.full(n, 3, dtype=np.int64)  # default: neutral

    for i in range(n):
        action_type = int(actions["type"][i])
        src = int(actions["source"][i])
        dest = int(actions["coord"][i])
        our_height = int(board.board[src] & 0x0F)

        if action_type == EAT_ACTION:
            keys[i] = 1

        elif action_type == CASCADE_ACTION:
            direction = int(actions["direction"][i])
            dest_count = int(actions["dest_count"][i])

            hits_enemy = any(
                board.board[src + step * direction] & opp_mask
                for step in range(1, dest_count + 1)
            )

            if hits_enemy:
                keys[i] = 2
            elif _has_stronger_enemy_neighbour(dest, our_height, board.board, opp_mask):
                keys[i] = 4

        else:
            dest_piece = int(board.board[dest])

            if dest_piece & opp_mask and (dest_piece & 0x0F) <= our_height:
                keys[i] = 2
            elif _has_stronger_enemy_neighbour(dest, our_height, board.board, opp_mask):
                keys[i] = 4

    sorted_indices = np.argsort(keys, kind="stable")
    return actions[sorted_indices]
