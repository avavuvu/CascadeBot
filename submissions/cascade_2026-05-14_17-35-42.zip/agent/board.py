import numpy as np

from .actions.types import CASCADE_ACTION, EAT_ACTION, MOVE_ACTION, PLACE_ACTION
from .piece import Piece
from .player_color import PlayerColor
from .transposition.keys import SIDE_KEY, TABLE

# Cached colour bit for RED — avoids importing PlayerColor inside the hot loop.
_RED_BIT = 0x10


def _is_valid_step(pos: int, direction: int) -> bool:
    """Return True if pos + direction stays inside the 8x8 board."""
    if direction == 8:
        return pos < 56  # South: not on last rank
    if direction == -8:
        return pos >= 8  # North: not on first rank
    if direction == 1:
        return pos % 8 < 7  # East:  not on last file
    if direction == -1:
        return pos % 8 > 0  # West:  not on first file
    return False


def _push_stack(board: np.ndarray, pos: int, direction: int) -> None:
    if not _is_valid_step(pos, direction):
        board[pos] = 0
        return
    next_pos = pos + direction
    if board[next_pos] != 0:
        _push_stack(board, next_pos, direction)
    board[next_pos] = board[pos]
    board[pos] = 0


class Board:
    PLACE_TURNS = 8  # 4 placements per player

    def __init__(self):
        self.board = np.zeros(64, dtype=np.uint8)
        self._turn: int = 0
        self._history: list[np.ndarray] = []
        self._turn_history: list[int] = []

        # -----------------------------------------------------------
        # Repetition tracking
        # _zobrist_key  : hash of the current position (board + side)
        # _position_counts : maps key → number of times it appears in
        #                    the history stack (not counting current).
        # _key_history  : stack of keys saved by make_move so that
        #                 unmake_move can restore them exactly.
        # -----------------------------------------------------------
        self._zobrist_key: int = 0  # empty board, RED to move → key = 0
        self._position_counts: dict[int, int] = {}
        self._key_history: list[int] = []

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def is_place_phase(self) -> bool:
        return self._turn < self.PLACE_TURNS

    @property
    def is_place_book(self) -> bool:
        return self._turn < 4

    @property
    def zobrist_key(self) -> int:
        """Zobrist hash of the current position (board state + side to move)."""
        return self._zobrist_key

    @property
    def is_repeated(self) -> bool:
        """
        True if the current board position has appeared before on the current
        game/search path (i.e. it exists in _position_counts).

        How the counts work
        -------------------
        When make_move is called we push the *current* key into
        _position_counts (we are leaving it, so it enters the history).
        When unmake_move is called we pop the previous key and decrement
        its count.  Therefore _position_counts[k] > 0 means position k
        was seen at some earlier point in the path — a true repetition.
        """
        return self._position_counts.get(self._zobrist_key, 0) > 0

    # ------------------------------------------------------------------
    # Zobrist helper
    # ------------------------------------------------------------------

    def _compute_zobrist(self, side_to_move: PlayerColor) -> int:
        """Recompute the Zobrist key from the current board array."""
        key = np.int64(0)
        for pos in np.flatnonzero(self.board != 0):
            piece = int(self.board[pos])
            color_idx = 0 if (piece & _RED_BIT) else 1
            height = piece & 0x0F
            key ^= TABLE[pos, color_idx, height]
        if side_to_move == PlayerColor.BLUE:
            key ^= SIDE_KEY
        return int(key)

    # ------------------------------------------------------------------
    # Move making / unmaking
    # ------------------------------------------------------------------

    def make_move(self, action: np.void, color: PlayerColor):
        self._history.append(self.board.copy())
        self._turn_history.append(self._turn)
        self._turn += 1

        # Save and count the current key — we are leaving this position,
        # so it now belongs to the history.
        old_key = self._zobrist_key
        self._key_history.append(old_key)
        self._position_counts[old_key] = self._position_counts.get(old_key, 0) + 1

        # Apply the move.
        if int(action["type"]) == int(CASCADE_ACTION):
            source = int(action["source"])
            direction = int(action["direction"])
            dest_count = int(action["dest_count"])

            self.board[source] = 0

            token = np.uint8(color.value | 1)

            for i in range(1, dest_count + 1):
                dest = source + i * direction
                if self.board[dest] != 0:
                    _push_stack(self.board, dest, direction)
                self.board[dest] = token

        elif int(action["type"]) == int(MOVE_ACTION):
            source = int(action["source"])
            coord = int(action["coord"])

            height = Piece.get_height(self.board[coord]) + Piece.get_height(
                self.board[source]
            )
            self.board[coord] = Piece.of(height, color)
            self.board[source] = 0

        elif int(action["type"]) == int(EAT_ACTION):
            source = int(action["source"])
            coord = int(action["coord"])

            self.board[coord] = self.board[source]
            self.board[source] = 0

        elif int(action["type"]) == int(PLACE_ACTION):
            coord = int(action["coord"])

            self.board[coord] = Piece.of(3, color)

        # Recompute the Zobrist key for the new position.
        # After this move it is the opponent's turn.
        self._zobrist_key = self._compute_zobrist(color.opponent())

    def unmake_move(self) -> bool:
        if not self._history:
            return False

        self.board[:] = self._history.pop()
        self._turn = self._turn_history.pop()

        # Restore the previous key and remove it from the history count.
        prev_key = self._key_history.pop()
        count = self._position_counts.get(prev_key, 0) - 1
        if count <= 0:
            self._position_counts.pop(prev_key, None)
        else:
            self._position_counts[prev_key] = count

        self._zobrist_key = prev_key
        return True

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    def is_color(self, index: int, color: PlayerColor) -> bool:
        return self.board[index] & color.value != 0

    def is_occupied(self, index: int) -> bool:
        return self.board[index] != 0

    def __str__(self) -> str:
        output = ""
        for row in range(8):
            for col in range(8):
                cell = self.board[row * 8 + col]
                if cell & PlayerColor.RED.value:
                    output += f"R{cell & 0x0F} ".ljust(4)
                elif cell & PlayerColor.BLUE.value:
                    output += f"B{cell & 0x0F} ".ljust(4)
                else:
                    output += ".   "
            output += "\n"
        return output
