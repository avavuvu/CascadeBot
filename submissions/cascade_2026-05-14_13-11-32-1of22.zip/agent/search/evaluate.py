import numpy as np

from ..board import Board
from ..player_color import PlayerColor


def evaluate(board: Board, color: PlayerColor) -> int:
    red_eval = _count_material(board, color)
    blue_eval = _count_material(board, color.opponent())

    eval = red_eval - blue_eval

    return eval * (-1 if color == PlayerColor.BLUE else 1)


def _count_material(board: Board, color: PlayerColor) -> int:
    color_mask = np.uint8(color.value)

    my_squares = np.flatnonzero(board.board & color_mask)
    heights = board.board & np.uint8(0x0F)
    my_heights = heights[my_squares]

    return int(np.sum(my_heights))
